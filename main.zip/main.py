'''
뭔 소린지 모르겠다
69:#REC 모드 켜짐
79:녹화 저장
470:labeling 버튼 함수
506 : REC (recording) 버튼 함수
522:display_video_stream : 큐에서 이미지 뽑아서 화면 출력

'''






import sys
from PySide6.QtWidgets import QApplication, QPushButton
