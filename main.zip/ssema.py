import threading
import queue
import time

# === [1] 괴상한 큐 2개 (컨베이어 벨트) ===
q_raw = queue.Queue()  # 재료팀 -> 가공팀 전달용
q_processed = queue.Queue()  # 가공팀 -> 사장님(Main) 전달용

# === [2] 세마포어 (신호등) ===
# 초기값 0: acquire() 하면 무조건 멈춤(대기), release() 하면 출발
sema_wait_worker = threading.Semaphore(0)  # 사장님이 직원을 기다리는 곳
sema_wait_main = threading.Semaphore(0)  # 직원이 사장님을 기다리는 곳

stop_flag = False  # "작업 중지" 깃발


# === [3] Thread_in (재료팀: 영상 캡처 역할) ===
def run_thread_in():
    cnt = 1
    while True:
        # [핵심] 멈춤 로직
        if stop_flag:
            print("[재료팀] 깃발 봄! 멈춥니다. (사장님께 신호 보냄)")
            sema_wait_worker.release()  # 1. 나 멈췄어 (사장님 깨움 +1)
            sema_wait_main.acquire()  # 2. 사장님이 가라고 할 때까지 잠듦 (-1 대기)
            print("[재료팀] 다시 일합니다!")

        # 일하기 (숫자 생성해서 Q1에 넣기)
        print(f"[재료팀] 재료 생성: {cnt}")
        q_raw.put(cnt)
        cnt += 1
        time.sleep(0.5)  # 작업 시간 시뮬레이션


# === [4] Thread_out (가공팀: 엣지 검출 역할) ===
def run_thread_out():
    while True:
        # [핵심] 멈춤 로직 (Thread_in과 동일)
        if stop_flag:
            print("    [가공팀] 깃발 봄! 멈춥니다.")
            sema_wait_worker.release()
            sema_wait_main.acquire()
            print("    [가공팀] 다시 일합니다!")

        # 일하기 (Q1에서 꺼내서 가공 후 Q2에 넣기)
        if not q_raw.empty():
            data = q_raw.get()
            result = data * 10  # 가공 (영상처리)
            print(f"    [가공팀] 가공 완료: {result} -> Q2로")
            q_processed.put(result)
        else:
            time.sleep(0.1)


# === 실행 ===
# 스레드 시작
t1 = threading.Thread(target=run_thread_in)
t2 = threading.Thread(target=run_thread_out)
t1.daemon = True
t2.daemon = True
t1.start()
t2.start()

# === Main (사장님: GUI 역할) ===
print("=== 공장 가동 ===")
time.sleep(2)  # 2초 동안은 그냥 지켜봄

print("\n!!! [사장님] 야 다 멈춰! (그래프 그려야 돼) !!!")
stop_flag = True  # 깃발 올림

# 1. 직원들이 멈출 때까지 기다림 (직원 수만큼 acquire)
# 직원이 release(+1) 해줄 때까지 여기서 멈춤
sema_wait_worker.acquire()
print(">>> 사장님: 재료팀 멈춘거 확인.")
sema_wait_worker.acquire()
print(">>> 사장님: 가공팀 멈춘거 확인.")

# 2. 여기서 안전하게 그래프 그리기 (Critical Section)
print("\n--- (사장님이 안전하게 그래프 그리는 중...) ---\n")
time.sleep(2)

# 3. 다시 일 시키기
print("!!! [사장님] 다시 일해! !!!")
stop_flag = False  # 깃발 내림
sema_wait_main.release()  # 재료팀 깨움 (+1)
sema_wait_main.release()  # 가공팀 깨움 (+1)

time.sleep(2)  # 잘 돌아가는지 구경
print("=== 퇴근 ===")