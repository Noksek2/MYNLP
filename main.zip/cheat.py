import threading
import sys
import time
import os
import pyautogui

import queue

import numpy as np
import cv2
from PySide6.QtCore import Qt, QThread, Signal, Slot, QSize, QTimer
from PySide6.QtGui import QAction, QImage, QPixmap, QCloseEvent
from PySide6.QtWidgets import (QApplication, QLineEdit, QComboBox, QGridLayout, QWidget,
                               QHBoxLayout, QLabel, QMainWindow, QPushButton,
                               QSizePolicy, QVBoxLayout, QWidget, QRadioButton, QScrollBar, QFrame)
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import torch
from torch.utils.data import TensorDataset, DataLoader
import torch.nn as nn
import torch.optim as optim
'''import random
import matplotlib

from sklearn.preprocessing import MinMaxScaler
import tensorflow as tf'''


sema0_1 = threading.Semaphore(0)
sema0_2 = threading.Semaphore(0)
sema1 = threading.Semaphore(0)
sema2 = threading.Semaphore(0)

Processing_stop = False

class Thread_in(threading.Thread):
    def __init__(self, img_queue):
        threading.Thread.__init__(self)
        self.status = True
        self.capture = None
        self.qu = img_queue
        self.vid = None
        self.MODE_REC = False
        self.MODE_REC_init = True
        self.out = None

    def run(self):
        self.capture = cv2.VideoCapture(self.vid)
        if not self.capture.isOpened():
            print("Camera open failed")

        prevTime = 0
        fps = 24
        while self.status:
            global Processing_stop
            if Processing_stop is True:
                sema1.release()
                sema0_1.acquire()

            curTime = time.time()  # 현재 시간
            sec = curTime - prevTime
            if sec > 1 / fps:
                prevTime = curTime
                ret, frame = self.capture.read()
                if not ret:
                    continue
                self.qu.put(frame)

                #녹화
                if self.MODE_REC is True:
                    if self.MODE_REC_init is True:
                        self.MODE_REC_init = False
                        w = round(self.capture.get(cv2.CAP_PROP_FRAME_WIDTH))
                        h = round(self.capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
                        fps = self.capture.get(cv2.CAP_PROP_FPS)

                        fourcc = cv2.VideoWriter_fourcc(*'DIVX')  # *'DIVX' == 'D', 'I', 'V', 'X'

                        #저장
                        self.out = cv2.VideoWriter('output_1.avi', fourcc, fps, (w, h))
                    self.out.write(frame)


        sys.exit(-1)


class Thread_out(threading.Thread):
    def __init__(self, img_queue, proc_queue):
        threading.Thread.__init__(self)
        self.status = True
        self.qu = img_queue
        self.qu_img_to_app = proc_queue
        self.EDGE_TYPE = None
        self.cnt = 0


    def run(self):
        global Processing_stop
        while self.status:
            if Processing_stop is True:
                sema2.release()
                sema0_2.acquire()
            if self.qu.qsize() > 0:
                cnt_edge = 10
                frame = self.qu.get()

                if self.EDGE_TYPE == 'Laplacian':
                    frame = cv2.Laplacian(frame, cv2.CV_8U, ksize=3)
                    # self.updatePlot.emit(frame)
                elif self.EDGE_TYPE == 'Canny':
                    frame = cv2.Canny(frame, 150, 300)
                    cnt_edge = self.sum_edge(frame)

                if len(frame.shape) < 3:
                    h, w = frame.shape
                    ch = 1
                    img_format = QImage.Format_Grayscale8
                else:
                    h, w, ch = frame.shape
                    img_format = QImage.Format_RGB888
                    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

                frame = QImage(frame.data, w, h, ch * w, img_format)
                frame = frame.scaled(640, 480, Qt.KeepAspectRatio)

                qu_val = [frame, cnt_edge]

                if self.qu_img_to_app.qsize() < 2:
                    self.qu_img_to_app.put_nowait(qu_val)


    def sum_edge(self, frame):
        ratio = 480 / frame.shape[0]
        img = cv2.resize(frame, None, fx=ratio, fy=ratio)
        temp = img > 0

        sum_value = temp.sum()
        return sum_value


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        # Title and dimensions
        self.setWindowTitle("Abnormal detection")
        self.setGeometry(0, 0, 1200, 500)

        try:self.model = torch.load("cnt_cls_model.pth", weights_only=False)
        except:
            self.model = None
            print('fuck you ')

        # self.m_main_img = None
        self.m_proc_img = None
        self.MODE_VIDEO = False
        self.th_in = None
        self.th_out = None
        self.EDGE_TYPE = None
        self.previous_plot = None
        self.labeling_capture = None
        self.labeling_Ground_truth = []
        self.cnt = 0
        self.vid = 0 # 카메라 번호

        self.y_max = 0
        self.canvas = FigureCanvas(Figure(figsize=(5, 2)))
        self.axes = self.canvas.figure.subplots()


        n_data = 50
        self.xdata = list(range(n_data))
        self.axes.set_xticks(self.xdata, [])
        self.ydata = [0 for i in range(n_data)]

        self.label_image = QLabel(self)

        self.img_size = QSize(640, 480)
        self.label_image.setFixedSize(self.img_size)

        self.scroll_bar = QScrollBar(Qt.Horizontal)  # 수평 스크롤바
        self.scroll_bar.setMinimum(0)  # 최소값 설정
        self.scroll_bar.setMaximum(100)  # 최대값 설정
        self.scroll_bar.setValue(0)  # 초기 값 설정
        self.scroll_bar.setVisible(False)
        self.scroll_bar.valueChanged.connect(self.change_frame)

        self.label_text_scroll = QLabel("Index Number: ")

        self.label_idx_scroll = QLabel()
        self.label_idx_scroll.setFrameStyle(QFrame.Box | QFrame.Raised)

        self.label_text_labeling = QLabel("Labeling(0 or 1): ")
        self.edit_text_labeling = QLineEdit()  #
        self.edit_text_labeling.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        self.edit_text_labeling.setFixedWidth(20)
        self.edit_text_labeling.setMaxLength(2)

        # 구간 레이블링 버튼
        self.button_start_labeling = QPushButton("section(Start)")
        self.button_end_labeling = QPushButton("section(End)")
        self.button_end_labeling.setEnabled(False)

        self.edit_section_label = QLineEdit()
        self.edit_section_label.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        self.edit_section_label.setFixedWidth(20)
        self.edit_section_label.setMaxLength(2)

        self.button_save_label = QPushButton("Save Label")
        self.button_training = QPushButton("Training")

        layout_label_canvas = QHBoxLayout()
        layout_label_canvas.addWidget(self.label_image)
        layout_label_canvas.addWidget(self.canvas)

        layout_save_training = QHBoxLayout()
        layout_save_training.addWidget(self.button_save_label)
        layout_save_training.addWidget(self.button_training)

        layout_scroll_idx = QHBoxLayout()
        layout_scroll_idx.addWidget(self.label_text_scroll, alignment=Qt.AlignmentFlag.AlignRight)
        layout_scroll_idx.addWidget(self.label_idx_scroll)
        layout_scroll_idx.addWidget(self.label_text_labeling, alignment=Qt.AlignmentFlag.AlignRight )
        layout_scroll_idx.addWidget(self.edit_text_labeling)
        layout_scroll_idx.addWidget(self.button_start_labeling)
        layout_scroll_idx.addWidget(self.edit_section_label)
        layout_scroll_idx.addWidget(self.button_end_labeling)


        self.label_clip_image = QLabel(self)

        # init widgets for perspective image
        self.m_pos_cnt = 0

        # init widgets for edge detection
        self.label_filter = QLabel("Filter type")
        self.button_edge_detection = QPushButton("Edge Detection")
        self._edgeType_combo_box = QComboBox()
        self._edgeType_combo_box.addItem("None")
        self._edgeType_combo_box.addItem("Sobel_XY")
        self._edgeType_combo_box.addItem("Scharr_X")
        self._edgeType_combo_box.addItem("Scharr_Y")
        self._edgeType_combo_box.addItem("Laplacian")
        self._edgeType_combo_box.addItem("Canny")

        # layout for edge detection
        edge_layout = QHBoxLayout()
        edge_layout.addWidget(self.label_filter, alignment=Qt.AlignmentFlag.AlignRight)
        edge_layout.addWidget(self._edgeType_combo_box)
        edge_layout.addWidget(self.button_edge_detection)

        # Load image buttons layout
        self.radiobutton_1 = QRadioButton("Image")
        self.radiobutton_2 = QRadioButton("Video")
        self.radiobutton_3 = QRadioButton("Webcam")
        self.radiobutton_1.setChecked(True)

        layout_loading_type = QHBoxLayout()
        layout_loading_type.addWidget(self.radiobutton_1)
        layout_loading_type.addWidget(self.radiobutton_2)
        layout_loading_type.addWidget(self.radiobutton_3)

        self.button_load_Img = QPushButton("Load Image")
        self.edit = QLineEdit("../images/moving_dark.mp4")
        self.button_REC = QPushButton("REC ▶")
        self.button_REC.setStyleSheet("QPushButton { background-color: green; color: white; padding: 10px 20px; }")
        self.button_REC.setEnabled(False)
        self.button_labeling = QPushButton("Labeling")

        self.button_load_Img.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        self.edit.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        self.button_REC.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        self.button_labeling.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)

        bottom_layout = QHBoxLayout()
        bottom_layout.addWidget(self.edit)
        bottom_layout.addLayout(layout_loading_type)
        bottom_layout.addWidget(self.button_load_Img)
        bottom_layout.addWidget(self.button_REC)
        bottom_layout.addWidget(self.button_labeling)

        layout_img_scroll = QVBoxLayout()
        # layout_img_scroll.addWidget(self.label_image)
        layout_img_scroll.addLayout(layout_label_canvas)
        layout_img_scroll.addWidget(self.scroll_bar)
        layout_img_scroll.addLayout(layout_scroll_idx)
        layout_img_scroll.addLayout(layout_save_training)


        # layout for image and graph
        layout_img_canvas = QHBoxLayout()
        layout_img_canvas.addLayout(layout_img_scroll)
        layout_img_canvas.addWidget(self.label_clip_image)

        # Main layout
        layout = QVBoxLayout()
        layout.addLayout(layout_img_canvas)
        layout.addLayout(bottom_layout)
        layout.addLayout(edge_layout)

        # Central widget
        widget = QWidget(self)
        widget.setLayout(layout)
        self.setCentralWidget(widget)

        # Connections
        self.button_load_Img.clicked.connect(self.load_img_func)
        self.button_REC.clicked.connect(self.recording)
        self.button_labeling.clicked.connect(self.labeling)
        self.button_edge_detection.clicked.connect(self.method_edge_detection)
        self.button_training.clicked.connect(self.training_perceptron)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.display_video_stream_v2)

    def update_plot2(self, sum_value):
        self.ydata = self.ydata[1:] + [sum_value]
        if sum_value > self.y_max:
            self.y_max = sum_value
            self.axes.set_ylim([0, self.y_max + 10])

        if self.previous_plot is None:
            self.previous_plot = self.axes.plot(self.xdata, self.ydata, 'r')[0]
        else:
            self.previous_plot.set_ydata(self.ydata)

        # Trigger the canvas to update and redraw.
        global Processing_stop
        Processing_stop = True
        sema1.acquire()
        sema2.acquire()

        prevTime = time.time()  # 현재 시간
        self.canvas.draw()
        Processing_stop = False
        sema0_1.release()
        sema0_2.release()
        curTime = time.time()  # 현재 시간
        sec = curTime - prevTime
        print(sec%60)


    def training_perceptron(self):
        print("Training...")

        path_split = self.edit.text().split('/')
        self.file_name = path_split[-1].split('.')
        train_y = np.load(f"{self.file_name[0]}.npy")   # 라벨 (0/1)
        print("train y len: ", len(train_y))
        print("train y size: ", train_y.size)

        # 1D 입력(feature) 만들기: 각 프레임마다 edge 개수
        features = []
        for i in range(len(self.frame_list)):
            frame = cv2.Canny(self.frame_list[i], 150, 300)

            ratio = 480 / frame.shape[0]
            img = cv2.resize(frame, None, fx=ratio, fy=ratio)

            temp = img > 0
            cnt_edge = temp.sum()          # 스칼라 값
            features.append(cnt_edge)

        # (N, 1) 모양의 입력
        train_x = np.array(features, dtype=np.float32)[:, np.newaxis]
        train_x = train_x / 30000.0

        # 라벨도 float32로 맞추고 (N, 1) 모양으로
        train_y = train_y.astype(np.float32).reshape(-1, 1)


        x_tensor = torch.from_numpy(train_x)  # shape: (N, 1)
        y_tensor = torch.from_numpy(train_y)  # shape: (N, 1)

        dataset = TensorDataset(x_tensor, y_tensor)
        dataloader = DataLoader(dataset, batch_size=50, shuffle=True)


        model = nn.Sequential(
            nn.Linear(1, 3),
            nn.ReLU(),
            nn.Linear(3, 1),
            nn.Sigmoid()
        )

        criterion = nn.BCELoss()
        optimizer = optim.RMSprop(
            model.parameters(),
            lr=0.001,
            alpha=0.9,     # Keras의 rho에 해당
            momentum=0.0
        )


        epochs = 2000
        for epoch in range(epochs):
            model.train()
            running_loss = 0.0

            for batch_x, batch_y in dataloader:
                optimizer.zero_grad()
                outputs = model(batch_x)          # shape: (batch, 1), sigmoid 결과
                loss = criterion(outputs, batch_y)
                loss.backward()
                optimizer.step()

                running_loss += loss.item() * batch_x.size(0)

            epoch_loss = running_loss / len(dataset)


            if (epoch + 1) % 100 == 0:
                print(f"[{epoch+1}/{epochs}] loss: {epoch_loss:.6f}")

        torch.save(model, "cnt_cls_model.pth")

        model.eval()
        with torch.no_grad():
            outputs = model(x_tensor)
            print(x_tensor)
            test_loss = criterion(outputs, y_tensor).item()

            preds = (outputs >= 0.5).float()
            correct = (preds == y_tensor).sum().item()
            test_acc = correct / len(y_tensor)

        print('테스트 손실:', test_loss)
        print('테스트 정확도:', test_acc)

        self.model=model

    def save_label(self):
        print("save label")
        save_Ground_truth = np.array(self.labeling_Ground_truth)
        path_split = self.edit.text().split('/')
        self.file_name = path_split[-1].split('.')
        np.save(f"./{self.file_name[0]}.npy", save_Ground_truth)

    def set_section_start(self):
        print("section start")
        self.start_idx = self.scroll_bar.sliderPosition()
        self.button_end_labeling.setEnabled(True)
        self.button_start_labeling.setEnabled(False)


    def set_section_end(self):
        print("section end")
        idx_i = self.start_idx
        idx_j = self.scroll_bar.sliderPosition()

        if idx_j > idx_i:
            label_value = [int(self.edit_section_label.text()) for i in range(idx_j-idx_i+1)]
            self.labeling_Ground_truth[idx_i:idx_j+1] = label_value
        elif idx_j < idx_i:
            label_value = [int(self.edit_section_label.text()) for i in range(idx_i - idx_j + 1)]
            self.labeling_Ground_truth[idx_j:idx_i+1] = label_value

        self.button_end_labeling.setEnabled(False)
        self.button_start_labeling.setEnabled(True)

    def set_label(self):

        if self.edit_text_labeling.text() == '0' or self.edit_text_labeling.text() == '1':
            self.labeling_Ground_truth[self.scroll_bar.sliderPosition()] = int(self.edit_text_labeling.text())
            print("changed label: ", self.labeling_Ground_truth[self.scroll_bar.sliderPosition()])

        else:
            print("Warning: input only [0 or 1]")

    def change_frame(self):
        cur_idx_of_scroller = self.scroll_bar.sliderPosition()
        # print("changed frame: ", cur_idx_of_scroller)
        self.update_image(self.frame_list[cur_idx_of_scroller])
        self.label_idx_scroll.setText(f"{cur_idx_of_scroller}")
        self.edit_text_labeling.setText(f"{self.labeling_Ground_truth[cur_idx_of_scroller]}")

    def labeling(self):
        print("labeling")
        self.kill_thread()
        self.labeling_capture = cv2.VideoCapture(self.edit.text())

        ret = True
        cnt = 0
        self.frame_list = []
        while ret:
            ret, frame = self.labeling_capture.read()

            if not ret:
                break
            cnt += 1
            self.frame_list.append(frame)
            self.labeling_Ground_truth.append(0)


        print("Loading video is complete")
        print(f"The number of frame: {len(self.frame_list)}  Ground-truth len: {len(self.labeling_Ground_truth)}" )
        self.scroll_bar.setMaximum(len(self.frame_list)-1)  # 최대값 설정
        self.scroll_bar.setVisible(True)

        # scroll의 index number QLabel과 Labeling의 QLineEdit을 초기값 설정
        self.label_idx_scroll.setText("0")
        self.edit_text_labeling.setText(f"{self.labeling_Ground_truth[0]}")

        self.labeling_capture.release()
        self.update_image(self.frame_list[0])

        self.edit_text_labeling.editingFinished.connect(self.set_label)
        self.button_start_labeling.clicked.connect(self.set_section_start)
        self.button_end_labeling.clicked.connect(self.set_section_end)
        self.button_save_label.clicked.connect(self.save_label)


    def recording(self):
        if self.th_in.MODE_REC is False:
            self.th_in.MODE_REC = True
            self.button_REC.setStyleSheet("QPushButton { background-color: red; color: white; padding: 10px 20px; }")
            self.button_REC.setText("REC ■")
        else:
            self.th_in.MODE_REC = False
            self.button_REC.setStyleSheet("QPushButton { background-color: green; color: white; padding: 10px 20px; }")
            self.button_REC.setText("REC ▷")
            self.th_in.out.release()


    def closeEvent(self, event):
        self.kill_thread()


    def display_video_stream_v2(self):
        if self.qu_img_to_app.empty() is False:

            qu_val = self.qu_img_to_app.get_nowait()

            frame = qu_val[0]
            cnt_edge = qu_val[1]

            self.update_image2(frame)

            '''if  is not None:
                print('You have model')'''
            print(self.qu_img_to_app.qsize())
            if self.EDGE_TYPE == 'Canny':
                if cnt_edge is not None and self.model is not None:
                    self.update_plot2(cnt_edge)

                    x = torch.tensor([[cnt_edge/30000.0]], dtype=torch.float32)
                    pred = self.model(x)
                    print('pred:',pred.item())
                    if pred>0.5:
                        pyautogui.hotkey('alt','tab')

    def update_image2(self, scaled_img):
        # Creating and scaling QImage
        self.label_image.setFixedSize(scaled_img.width(), scaled_img.height())
        self.label_image.setPixmap(QPixmap.fromImage(scaled_img))



    def method_edge_detection(self):
        if self.MODE_VIDEO is True:
            if self._edgeType_combo_box.currentText() == 'None':
                self.th_out.EDGE_TYPE = None
                return
            elif self._edgeType_combo_box.currentText() == 'Canny':
                self.th_out.EDGE_TYPE = 'Canny'
                self.EDGE_TYPE = 'Canny'
                return
            elif self._edgeType_combo_box.currentText() == 'Laplacian':
                self.th_out.EDGE_TYPE = 'Laplacian'
                self.EDGE_TYPE = 'Laplacian'
                return

        if self.m_proc_img is not None:
            if len(self.m_proc_img.shape) >= 3:
                self.m_proc_img = cv2.cvtColor(self.m_proc_img, cv2.COLOR_BGR2GRAY)

            if self._edgeType_combo_box.currentText() == 'Sobel_XY':
                print("Sobel_XY")
                sobel_img = cv2.Sobel(self.m_proc_img, cv2.CV_8U, 1, 1, ksize=3)
                self.update_image(sobel_img)
            elif self._edgeType_combo_box.currentText() == 'Scharr_X':
                print("Sobel_X")
                s_imageX = cv2.Scharr(self.m_proc_img, cv2.CV_8U, 1, 0)
                self.update_image(s_imageX)
            elif self._edgeType_combo_box.currentText() == 'Scharr_Y':
                print("Sobel_Y")
                s_imageY = cv2.Scharr(self.m_proc_img, cv2.CV_8U, 0, 1)
                self.update_image(s_imageY)
            elif self._edgeType_combo_box.currentText() == 'Laplacian':
                print("Laplacian")
                l_image = cv2.Laplacian(self.m_proc_img, cv2.CV_8U, ksize=3)
                self.update_image(l_image)
            elif self._edgeType_combo_box.currentText() == 'Canny':
                print("Canny")
                c_image1 = cv2.Canny(self.m_proc_img, 150, 300)
                self.update_image(c_image1)


    def update_image(self, img):
        # Creating and scaling QImage
        if len(img.shape) < 3:
            h, w = img.shape
            ch = 1
            img_format = QImage.Format_Grayscale8
        else:
            h, w, ch = img.shape
            img_format = QImage.Format_RGB888
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        img = QImage(img.data, w, h, ch * w, img_format)
        scaled_img = img.scaled(640, 480, Qt.KeepAspectRatio)
        self.label_image.setFixedSize(scaled_img.width(), scaled_img.height())
        self.label_image.setPixmap(QPixmap.fromImage(scaled_img))

    def load_img_func(self):
        self.kill_thread()
        if self.radiobutton_1.isChecked() is True:
            self.MODE_VIDEO = False
            self.m_main_img = cv2.imread(f"{self.edit.text()}", cv2.IMREAD_COLOR)
            self.m_main_img = cv2.resize(self.m_main_img, (640, 480), interpolation=cv2.INTER_CUBIC)
            self.m_proc_img = self.m_main_img.copy()
            self.update_image(self.m_proc_img)
            print("update image")
        elif self.radiobutton_2.isChecked() is True:
            path = self.edit.text()
            self.createThread_start(path)

        elif self.radiobutton_3.isChecked() is True:
            self.createThread_start(self.vid)
            self.button_REC.setEnabled(True)



    def createThread_start(self, vid):
        self.MODE_VIDEO = True
        self.qu = queue.Queue()
        self.qu_img_to_app = queue.Queue()
        self.th_in = Thread_in(self.qu)
        self.th_out = Thread_out(self.qu, self.qu_img_to_app)

        self.th_in.vid = vid
        self.th_in.start()
        self.th_out.start()
        self.timer.start(15)
    def kill_thread(self):
        self.timer.stop()
        if self.th_in is not None:
            if self.th_in.is_alive() is True:
                self.th_in.status = False
                self.th_in.join()
                print("Thread_in END")
            if self.th_in.capture is not None:
                if self.th_in.capture.isOpened is True:
                    self.th_in.capture.release()

        if self.th_out is not None:
            if self.th_out.is_alive() is True:
                self.th_out.status = False
                self.th_out.join()
                print("Thread_out END")

        if self.labeling_capture is not None:
            self.labeling_capture.release()


if __name__ == "__main__":
    app = QApplication()
    w = Window()
    w.show()
    sys.exit(app.exec())
'''






'''